<?php
	$title = "Calculus - Quiz 1";
	require_once("includes/header.inc.php");
?>


	<script>
		function scrollWin(){
			window.scrollTo(0, 0);
		}
		function $( ele ) {
			return document.getElementById( ele );
		}
		var answers1 = ["4"];//put all the answers in vars
		var answers2 = ["0"];
		var answers3 = ["A"];
		var answers4 = ["2"];
		var numCorrect = 0;
		function submitForm(){
			console.log("entered validate");
			var wrongMsg = ""; //message that will say which is wrong
			var answer1 = document.forms[0].question1.value;
			var answer2 = document.forms[0].question2.value;
			var answer3 = document.forms[0].question3.value;
			var answer4 = document.forms[0].question4.value;
			for(i = 0; i < answers1.length; i++){
				if(answer1 == answers1[i]){
					numCorrect += 1;
				}
				else{
					wrongMsg += "Question 1 wrong, correct answer is: " + answers1[0] + " <br/>";
					$( "ques1" ).style.border = "5px solid red";
					$( "q1answer1" ).src = "resources/quiz1q4ans.PNG";
				}
				if(answer2 == answers2[i]){
					numCorrect += 1;
				}
				else{
					wrongMsg += "Question 2 wrong, correct answer is: " + answers2[0] + " <br/>";
					$( "ques2" ).style.border = "5px solid red";
					$( "q1answer2" ).src = "resources/quiz1q1ans.PNG";
				}
				if(answer3 == answers3[i]){
					numCorrect += 1;
				}
				else{
					wrongMsg += "Question 3 wrong, correct answer is: " + answers3[0] + " <br/>";
					$( "ques3" ).style.border = "5px solid red";
					$( "q1answer3" ).src = "resources/quiz1q2ans.PNG";
				}
				if(answer4 == answers4[i]){
					numCorrect += 1;
				}
				else{
					wrongMsg += "Question 4 wrong, correct answer is: " + answers4[0] + " <br/>";
					$( "ques4" ).style.border = "5px solid red";
					$( "q1answer4" ).src = "resources/quiz1q3ans.PNG";
				}
				scrollWin();
				if( wrongMsg ){
					var resultsDiv = $( "results" );
							
					$( "results" ).innerHTML =
					"The following were incorrect. Look below for the correct solutions.<br/>" + wrongMsg;
					$( "results" ).style.display = "block";
					
					//resultsDiv = $( "q1answer1" );
					//$( "q1answer1" ).innerHTML =
					//"<img src='resources/quiz1q1.PNG' width='40%' height='40%' alt='question1'>";
					//$( "q1answer1" ).style.display = "block";
					return false; // prevent form from submitting
				}
				return true;
			}
		}
	</script>
	<body id="quizzes"><!--Use for first part of active css-->
	<header>
		<h1>Quiz 1 - Basics of Derivatives</h1>
	</header>
	<!--#include file="includes/navbar.html" --> <!-- Includes the nav bar, starts with <nav> ends with </nav>-->
	
	<!--Quiz content below-->
	<form action="quiz1.shtml" method="post" name="form" 
		onsubmit="return submitForm();">
		
		<div id="quizContent">
			<div id="results"></div>
			<h3>Question 1</h3>
			<p>
				<img id="ques1" class="thumbnail" src="resources/quiz1q1.PNG" alt="question1">
				<img id="q1answer1" src="" alt=""><br/>
				Your Answer:
				<input type="text"
					name="question1"
					id="question1"
					maxlength="14"
					required="required"/>
				
			</p><br/><br/>
			<h3>Question 2</h3>
			<p>
				<img id="ques2" src="resources/quiz1q2.PNG" alt="question2">
				<img id="q1answer2" src="" alt=""><br/>
				Your Answer:
				<input type="text"
					name="question2"
					id="question2"
					maxlength="14"
					required="required"/>
			</p><br/><br/>
			<h3>Question 3</h3>
			<p>
				<img id="ques3" src="resources/quiz1q3.PNG" alt="question3">
				<img id="q1answer3" src="" alt=""><br/>
				Your Answer:
				<input type="text"
					name="question3"
					id="question3"
					maxlength="1"
					required="required"/>
			</p><br/><br/>
			<h3>Question 4</h3>
			<p>
				<img id="ques4" src="resources/quiz1q4.PNG" alt="question4">
				<img id="q1answer4" src="" style="margin-left:9%" alt=""><br/>
				Your Answer:
				<input type="text"
					name="question4"
					id="question4"
					maxlength="1"
					required="required"/>
			</p><br/><br/>
			<button id="submit">Submit Quiz</button>
		</div>
	</form>
	<script src="includes/sidebarscript.js"></script>
</body>

</html>