<?php
	$title = "Home";
	require_once("includes/header.inc.php");

?>


  <div id="homepageBlock" style="width:950px; height: 750px; background-color:#282828;">
    <img style="border: 2px solid grey; width:100%; height:30%;" src="resources/greenbanner.jpg">
	<p>
	Why learn Calculus? This is a question that everyone who's heard of calculus undoubtedly will ask themselves at some point.
	Even if we think we will never be able to apply the lessons of Calculus to our own lives, just the meer act of studying it
	can allow us to think about numbers in a whole new way! 
	</p>
	<p>
	Although learning a rigorous math subject such as Calculus may seem daunting, it's really not as difficult as others may make 
	it seem! There are some places in the United States where students as young as fifth grade are learning the basics of Calculus, 
	so why not you? 
	</p>
	<p>
	You can begin by taking a look at the lessons available on the site. Once you've completed a lesson, take the matching quiz 
	to set the knowledge you've gained deep into your memory. Once you're able to complete the quiz without assistance, then you're
	ready for the next topic! 
	</p>
	<p>
	Upon completion of all of the quizzes, you should be able to perform extremely well in any Calculus 
	course and have a basic understanding of the topic even without a course to take alongside.
	</p>
  </div>

  
  <!-- Footer -->
  <footer class="w3-padding-64 w3-light-grey w3-small w3-center" id="footer">
   






  </footer>

  <div class="w3-black w3-center w3-padding-24"></div>

  <!-- End page content -->
</div>

<script src="includes/sidebarscript.js"></script>

</body>
</html>