<?php
	$title = "Calculus - Application - Lesson 1";
	require_once("includes/header.inc.php");
?>
 <script>
  function changePic1()
  {
    document.getElementById('ex1').src='resources/app4.png';
  }
  function changePic2()
  {
    document.getElementById('ex1').src='resources/app3.png';
  }
  function changePic3()
  {
    document.getElementById('ex2').src='resources/app6.png';
  }
  function changePic4()
  {
    document.getElementById('ex2').src='resources/app5.png';
  }
 
  </script>
<div class="w3-container w3-text-grey" id="L1"> 
  <p>Mean Value Theorem </p></div>

  <div class="board">
    <div class= "imgs" id= "yeet"> <img src="resources/app1.png" id="img1"/> </div>
    <div class="whitefont">
    <h2> Textbook Definition of Mean Value Theorem </h2> 
    <p> From <i>Calculus Early Transcendentals 8th Ed [2015] </i></p>
    <p> Honestly for Mean Value Theorem, all you need to be able to do is memorize the equation for the MVT and be able to plug in the needed values.  </p>
    <p>Check out the problem below.</p>

    <br/><br/>
    <div class= "imgs" id="yeet"> <img src="resources/app2.png" id="img1"> </div>
    <br/>
    <p> 
    So first thing you want to do is note down all the given values and information that is present in the problem. The problem tells you the function equation, the values of a and b and states that f is a continuous and differentiable polynomial for all x. So we would use the Mean Value Theorem to find out the number c  in the given intervals. Plug it into the equation, in which the only difficulty you should really have is finding the derivative of the function. After simplifying the MVT, solve for c. </p>
    <br/><br/>
    <p class="push">
    Other uses for the Mean Value Theorem is that it can be used to establish some of the basic facts of differential calculus, which consist of theorems such as " If the derivative of f(x) equal to 0 for all x in an interval (a,b), then f is constant on (a,b). 
    </p>
 	<br/>

  
    </div>

    </div>
  
    <p> <div>Sample Problems <br/> *Analyzing other Problems and how they are solved are great ways to understand how to find the derivative of a function*<br/> *Make sure you attempt the questions before checking the answers. <b> Also, utilize the sample question that was given already. </b> </div> </p>
  
  <!-- Footer -->
    <div class="foot" id="footer">
    <br/>
<center>
        <p><div class="pratice"><img id="ex1" src="resources/app3.png" alt="Example 5"/></div><br/>
          <button id="answer" onclick="changePic1()">Answer</button>
          <button id="question" onclick="changePic2()">Back to Question</button>
        </p><br/>
        
        <p><div class="pratice"><img id="ex2" src="resources/app5.png" alt="Example 6"/><br/></div>
          <button id="answer2" onclick="changePic3()">Answer</button>
          <button id="question2" onclick="changePic4()">Back to Question</button>
        </p><br/>
        
      </center>
  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>
  </div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>