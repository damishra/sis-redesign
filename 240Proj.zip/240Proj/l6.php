<?php
	$title = "Calculus - Lesson 6";
	require_once("includes/header.inc.php");
?>
<script>
function changePic1()
  {
    document.getElementById('ex1').src='resources/l6/p3.png';
  }
  function changePic2()
  {
    document.getElementById('ex1').src='resources/l6/p2.png';
  }
  function changePic3()
  {
    document.getElementById('ex2').src='resources/l6/p5.png';
  }
  function changePic4()
  {
    document.getElementById('ex2').src='resources/l6/p4.png';
  }
  function changePic5()
  {
    document.getElementById('ex3').src='resources/l6/p7.png';
  }
  function changePic6()
  {
    document.getElementById('ex3').src='resources/l6/p6.png';
  }
</script>
  <div class="w3-container w3-text-grey" id="L1"> 
  <p>The power rule combined with the chain rule</p></div>

  <div style="width:950px; height: 750px; background-color:black;">
    <div style="color:white;">
    <br/>
    
    <div style="border: 4px solid black; float: left;"><img src="resources/l6/p1.png" alt="picture 1" width="500px" height="150px"></div>
    <p><u>The Power Rule Combined with the Chain Rule</u>
	To fully understand this Rule it is important to remember the pattern behind it.
	</p><br/><br/><br/><br/>
	
	
	 <center>
        <p><img id="ex1" src="resources/l6/p2.png" alt="Example 1" style="height:25%;width:35%;"/><br/>
          <button id="answer" onclick="changePic1()">Answer</button>
          <button id="question" onclick="changePic2()">Question</button>
          </p><br/><br/><br/>
        <p><img id="ex2" src="resources/l6/p4.png" alt="Example 2" style="height:25%;width:35%;"/><br/>
          <button id="answer" onclick="changePic3()">Answer</button>
          <button id="question" onclick="changePic4()">Question</button>
          </p>
          <p>
        In these examples above, there is a pattern present in both problems. In the first
		problem, the Power Rule is used as the power of 100 is subtracted by 1 which becomes 
		99 and the 100 is also the new coefficient. However after using the Power rule,
		the function is still differentiable which then allows us to find to multiply
		the derivative to that function to the result of the power rule.<br/>
￼
		In these examples above, there is a pattern present in both problems. In the first
		problem, the Power Rule is used as the power of 100 is subtracted by 1 which becomes 99 and
		 the 100 is also the new coefficient. However after using the Power rule, the function is
		  still differentiable which then allows us to find to multiply the derivative to that function to the result of the power rule.
		Something to keep in mind is that problems that require The Power Rule Combined with the
		 Chair Rule, tend to have a function to the power of an exponent.
		These technique of combing the power rule and the chain rule can also be used with the product rule which an example will be shown below.  
</p>
        <p><img id="ex3" src="resources/l6/p6.png" alt="Example 3" style="height:25%;width:35%;"/><br/>
          <button id="answer" onclick="changePic5()">Answer</button>
          <button id="question" onclick="changePic6()">Question</button>
        </p><br/><br/><br/>
        </center>
        
      

  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>