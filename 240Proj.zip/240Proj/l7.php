<?php
	$title = "Calculus - Lesson 7";
	require_once("includes/header.inc.php");
?>
<script>
function changePic1()
  {
    document.getElementById('ex1').src='resources/l7/p2.png';
  }
  function changePic2()
  {
    document.getElementById('ex1').src='resources/l7/p1.png';
  }
</script>
  <div class="w3-container w3-text-grey" id="L1"> 
  <p>Implicit Differentiation</p></div>

  <div style="width:950px; height: 750px; background-color:black;">
    <div style="color:white;">
    <br/>
    <p><u>Implicit Differentiation</u><br/>
    One pattern that you will notice with these problems is that it will have two variables in the function. The problem above is asking for the double derivative of y.
    The first step is to find the derivative of each term. X to the 4th power becomes 4(x to the 3rd power) and
     16 becomes 0. However the y to the 4th power becomes 4(y to the 3rd power)
    times the first derivative of y. Next isolate the first derivative of y. That’s how you generally solve
     implicit differentiation problems. Sometimes they will ask for the second derivative, so you going to have
      to find the derivative of the 1st derivative.</p>
    
	 <center>
        <p><img id="ex1" src="resources/l7/p1.png" alt="Example 1" style="height:25%;width:35%;"/><br/>
          <button id="answer" onclick="changePic1()">Answer</button>
          <button id="question" onclick="changePic2()">Question</button>
        </p><br/><br/><br/>
        
        </center>

  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>