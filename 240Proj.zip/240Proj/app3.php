<?php
	$title = "Calculus - Application - Lesson 3";
	require_once("includes/header.inc.php");
?>
 <script>
  function changePic1()
  {
    document.getElementById('ex1').src='resources/ap15.png';
  }
  function changePic2()
  {
    document.getElementById('ex1').src='resources/ap13.png';
  }
  function changePic3()
  {
    document.getElementById('ex2').src='resources/ap16.png';
  }
  function changePic4()
  {
    document.getElementById('ex2').src='resources/ap14.png';
  }
 
  </script>
<div class="w3-container w3-text-grey" id="L1"> 
  <p>How Derivatives Affect the Shape of a Graph 
</p></div>

  <div class="board">
   <div class="whitefont">
   <br/>
   <h2> What to know </h2>
    <div class="imgs" id= "yeet"> <img src="resources/ap7.png" id="img2"/> </div>
    <br/>
    <p> To do well on this topic, all you really have to do memorize the theorems and concepts. In addition, though, these concepts are very easy to memorize.</p>

    <div class="imgs" id="yeet"> <img src="resources/ap8.png" id="img3"> </div>
    <div class="imgs" id="yeet"> <img src="resources/ap9.png" id="img3"> </div>
    <div class="imgs" id="yeet"> <img src="resources/ap10.png" id="img2"> </div>
    <br/><br/><br/><br/>
    <p>Obviously the first step is to find the derivative of the function given in Example 1. 
    </p>

    <br/><br/><br/>
    
   <p> Next is to make the derivative of the function equal to 0.  In which we get the critical points of 
X = 0, 2, -1. Then we set those as intervals to another to find out when the graph of the f(x) increases or decreases in those intervals, as seen below. <br/><br/>
  One thing to keep in mind are the intervals are set to the critical points that we determined. To find out whether its increasing and decreasing is up to the middle part of the table above. Subbing in x into the expressions 12x, x -2, x +1 tend to confuse people as they don’t know what to substitute x with. Possible values to substitute must satisfy the domain intervals. And from that you can see when it increases and decreases seen in the chart. 

</p>
    <br/>
 	<br/>

  
    </div>

    </div>
  
    <?php
    require_once("includes/tip.inc.php");
    ?>
  
  <!-- Footer -->
    <div class="foot" id="footer">
    <br/>
<center>
        <p><div class="pratice"><img src="resources/ap12.png" alt="ffdf" id="img3"></div></p>
        <p><div class="pratice"><img id="ex1" src="resources/ap13.png" alt="Example 5"/></div><br/>
          <button id="answer" onclick="changePic1()">Answer</button>
          <button id="question" onclick="changePic2()">Back to Question</button>
        </p><br/>
        
        <p><div class="pratice"><img id="ex2" src="resources/ap14.png" alt="Example 6"/><br/></div>
          <button id="answer2" onclick="changePic3()">Answer</button>
          <button id="question2" onclick="changePic4()">Back to Question</button>
        </p><br/>
        
      </center>
  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>
  </div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>