<?php
	$title = "Calculus - Lesson 3";
	require_once("includes/header.inc.php");
?>
  <div class="w3-container w3-text-grey" id="L1"> 
  <p>Differentiation Rules || part 2</p></div>

  <div style="width:950px; height: 750px; background-color:black;">
    <div style="color:white;">
    
    <div style="border: 4px solid black; float: left;"><img src="resources/l3/p1.png" alt="picture 1" width="500px" height="90px"></div>
    <p><u>The Sum/Difference Rule.</u>
	In general what you are just doing is using what you know of the Power Rule and deriving all the terms individually and
	then apply the given arithmetic operations. The same applies to the Difference Rule.</p>
    <div style="border: 4px solid black; float: left;"><img src="resources/l3/p2.png" alt="picture 2" width="500px" height="90px"></div>
    <div style="border: 4px solid black; float: left;"><img src="resources/l3/p3.png" alt="picture 3" width="500px" height="220px"></div>
    <br/><p>The problem above shows how to use both the sum rule and the difference rule when finding the derivative of a function. All the terms are broken up 
    and the derivative of each are found individually in which then they are all combined together.</p>
    <br/><br/><br/><br/><br/><br/><br/><br/><br/>
    <div style="border: 4px solid black; float: left;"><img src="resources/l3/p4.png" alt="picture 4" width="500px" height="90px"></div>
    <p><u>The Derivative of the Natural Exponential Function</u>
	An important concept to remember as all there is that the derivative of e to the x power is just e to the x power.
 	NOTHING CHANGES. Use this concept when deriving a function by parts.</p>
    <div style="border: 4px solid black; float: left;"><img src="resources/l3/p5.png" alt="picture 5" width="500px" height="200px"></div>
    <div style="border: 4px solid black; float: right;"><img src="resources/l3/p6.png" alt="picture 6" width="180px" height="80px"></div>
    <p><u>Derivative of natural log</u>
	Another important concept to remember and be able to use with the other derivative rule.</p>
	<div style="border: 4px solid black; float: left;"><img src="resources/l3/p7.png" alt="picture 7" width="500px" height="200px"></div>
    <p>First step was using the chain rule. Finding the derivitive of the function however would require you to use the</p>
    <br/><br/>

  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>