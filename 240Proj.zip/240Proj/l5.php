<?php
	$title = "Calculus - Lesson 5";
	require_once("includes/header.inc.php");
?>
<script>
function changePic1()
  {
    document.getElementById('ex1').src='resources/l5/p3.png';
  }
  function changePic2()
  {
    document.getElementById('ex1').src='resources/l5/p2.png';
  }
</script>
  <div class="w3-container w3-text-grey" id="L1"> 
  <p>Derivatives of Trigonometric and inverse Trigonometric</p></div>

  <div style="width:950px; height: 750px; background-color:black;">
    <div style="color:white;">
    <br/>
    <p>The key about this is that it is all about memorization.</p>
    <div style="border: 4px solid black; float: left;"><img src="resources/l5/p1.png" alt="picture 1" width="500px" height="190px"></div>
    <p>
	The first approach is to use the Quotient Rule. The second step is to use the Table of derivatives of Trigonometric Functions, so you can easily plug in the derivatives of the
￼￼	numerator and denominator. The third step is to simplify any trigonometry present as shown in the work above. Techniques such as trig relations and distributive property</p>
	 <br/><br/><br/><br/>
	 <center>
        <p><img id="ex1" src="resources/l5/p2.png" alt="Example 1" style="height:25%;width:35%;"/><br/>
          <button id="answer" onclick="changePic1()">Answer</button>
          <button id="question" onclick="changePic2()">Question</button>
        </p><br/><br/><br/>
        
        </center>

  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>