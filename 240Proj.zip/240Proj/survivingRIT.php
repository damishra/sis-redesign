<?php
	$title = "Surviving RIT";
	require_once("includes/header.inc.php");
?>
<script>
    function $ (ele) {
            return document.getElementById(ele);
        }

        function validate(){
            var errMsg = "";
            //var state = document.getElementById('state');
            //var invalid = state.value == " ";


            if  ( !$("fullname").value) {
                errMsg += "Fullname <br/>"
                $("1").style.color  = "red";

            }

            else {
                $("1").style.color = "black";
            }

            if ( !$("email").value) {
                errMsg += "Email Address <br/>"
                $("2").style.color  = "red";
            }
            else {
                $("2").style.color = "black";
            }


        if (errMsg) { 
            
                
            return false;
        }
        return true;

    }


</script>
<body id="lessons">
	<!--#include file="includes/navbar.html" --> <!-- Includes the nav bar, starts with <nav> ends with </nav>-->
		<div id="surviveContent">
			<p>
			If you are a RIT student you may have difficulty navigating the math department. If you have transfer credits they may satisfy some requirement but most likely you will still need to take some math classes at RIT. To do so you need to take the RIT Math Placement Exam (MPE) [https://www.rit.edu/science/sms/mpe] this exam will determine your skill level and allow you to place into classes. If the class you are trying to place into is a low level class you may not be required to take the exam, or if your credits are satisfied via transfer credits you likewise may not need to take the exam. In either case you can talk to your academic adviser to determine your class requirements.
			</p>
			<p>
			RIT has many resources available for students. Your academic advisor is one of the most useful, they can connect you to resources across campus. In addition to your advisor you can also get free math tutoring on campus at the <a href = "https://www.rit.edu/studentaffairs/asc/math-and-physics-support/math-physics-tutoring"> Bates & Sol study center </a>.
			</p>
			<p>
			If your looking for information on a specific teacher rate my professor is a great resource for any college. In addition to that there is a RIT specific teacher evaluation called OpenEvals. This tool uses rit students survey answers to rate professors. It is specific to RIT and the ratings are guaranteed to be from a RIT student that took that class.
			 <a href="http://www.ratemyprofessors.com/campusRatings.jsp?sid=807">Visit Rate My Professor</a> 
			  <a href="https://openevals.rit.edu/search">Visit Open Eval</a> 
			</p>
			<pre>
The Math department office is located at
1102 Thomas Gosnell Hall
RIT College of Science
85 Lomb Memorial Drive
Rochester, NY 14623
			</pre>
			
			<p>
				There are also some great links to other resources you might be interested in
				<ul>
					<li><a href="http://library.rit.edu/">RIT library </a></li>  
					<li><a href="https://www.rit.edu/science/home">The math departments website </a></li>  
					<li><a href="https://goo.gl/NvCBsf">The math tutoring schedule </a></li>  
					<li><a href="https://www.rit.edu/studentaffairs/asc/tutoring-and-tutor-training/where-can-i-find-tutor">RIT tutoring information for all subjects </a> </li> 
					<li><a href="https://www.rit.edu/studentaffairs/asc/math-and-physics-support/math-related-sites">RIT recommended math sites </a> </li> 
					<li><a href="https://www.rit.edu/studentaffairs/asc/tutoring-and-tutor-training/tutoring-rit">RIT Tutoring information </a></li> 

			</p>
			
		</div>
		<script src="includes/sidebarscript.js"></script>
	</body>

</html>
