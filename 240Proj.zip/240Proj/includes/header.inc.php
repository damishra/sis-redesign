

<?php include('server.php') ?>

<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
  }

  if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);

  }

?>

<!DOCTYPE html>
<html>
<title><?= $title ?></title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="ff.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
.w3-sidebar a {font-family: "Roboto", sans-serif}
body,h1,h2,h3,h4,h5,h6,.w3-wide {font-family: "Montserrat", sans-serif;}
</style>
<body class="w3-content" style="max-width:1200px">

<!-- Sidebar/menu -->
<nav class="w3-sidebar w3-bar-block w3-white w3-collapse w3-top" style="z-index:3;width:250px" id="mySidebar">
  <div class="w3-container w3-display-container w3-padding-16">
    <i onclick="w3_close()" class="fa fa-remove w3-hide-large w3-button w3-display-topright"></i>
    <h3 class="w3-wide"><b>Calculus</b></h3>
  </div>
  <div class="w3-padding-64 w3-large w3-text-grey" style="font-weight:bold">
      
      <a href="index.php" class="w3-bar-item w3-button" style="color: black;"> 
      <?php  if (isset($_SESSION['username'])) : ?> Welcome <?php echo $_SESSION['username']; ?>
      </a>

      <a href="index.php?logout='1'" class="w3-bar-item w3-button" style="color: black;">Logout</a>
    <?php endif ?>

    
    <a href="index.php" class="w3-bar-item w3-button">Home</a>
    
    <a onclick="myAccFunc()" href="javascript:void(0)" class="w3-bar-item w3-button">
      Lessons <i class="fa fa-caret-down"></i></a>
        
        <div id="demoAcc" class="w3-bar-block w3-hide w3-padding-large w3-medium">

        <a onclick="myAccFunc3()" href="javascript:void(0)" class="w3-bar-item w3-button"> Derivatives <i class="fa fa-caret-down"></i></a>
            <div id="demoGcc" class="w3-bar-block w3-hide w3-padding-large w3-medium">
            <a href="l1.php" class="w3-bar-item w3-button">Basics of Derivatives || Other Notations </a>
            <a href="l2.php" class="w3-bar-item w3-button">Differentiation Rules || Part 1 </a>
            <a href="l3.php" class="w3-bar-item w3-button">Differentiation Rules || Part 2</a>
            <a href="l4.php" class="w3-bar-item w3-button">The Product and Quotient Rules</a>
            <a href="l5.php" class="w3-bar-item w3-button">Derivatives of Trig and Inverse Trig</a>
            <a href="l6.php" class="w3-bar-item w3-button">The Power Rule Combined with the Chain Rule</a>
            <a href="l7.php" class="w3-bar-item w3-button">Implicit Differentiation</a>
            <a href="l8.php" class="w3-bar-item w3-button">Logarithmic Differentiation</a></div>

      
        <a onclick="myAccFunc4()" href="#" class="w3-bar-item w3-button">Integrals<i class="fa fa-caret-down"></i></a>
            <div id="demoGcc1" class="w3-bar-block w3-hide w3-padding-large w3-medium">
            <a href="int1.php" class="w3-bar-item w3-button">Fundamental Theorems of Calculus </a>
            <a href="int2.php" class="w3-bar-item w3-button">Definite Integrals</a>
            <a href="int3.php" class="w3-bar-item w3-button">Indefinite Integrals</a>
            <a href="int4.php" class="w3-bar-item w3-button">U-Substitution</a>
            <a href="int5.php" class="w3-bar-item w3-button">Integration by Parts</a>
            </div>

        <a onclick="myAccFunc5()" href="#" class="w3-bar-item w3-button">Applications<i class="fa fa-caret-down"></i></a>
            <div id="demoGcc2" class="w3-bar-block w3-hide w3-padding-large w3-medium">
            <a href="app1.php" class="w3-bar-item w3-button">Mean Value Theorem</a>
            <a href="app2.php" class="w3-bar-item w3-button">Max and Min of a Function</a>
            <a href="app3.php" class="w3-bar-item w3-button">How Derivatives Affect the Shape of a Graph</a>
            <a href="app4.php" class="w3-bar-item w3-button">Lesson 4</a>
            </div>

    </div>
    <a onclick="myAccFunc1()" href="javascript:void(0)" class="w3-bar-item w3-button">
      Quizzes <i class="fa fa-caret-down"></i>
    </a>  
	
      <!-- bars under quizzes -->	
      <div id="demoTcc" class="w3-bar-block w3-hide w3-padding-large w3-medium">
        <a onclick="myAccFunc6()" href="javascript:void(0)" class="w3-bar-item w3-button"> Derivatives <i class="fa fa-caret-down"></i></a>
            <div id="demoGcc3" class="w3-bar-block w3-hide w3-padding-large w3-medium">
            <a href="quiz1.php" class="w3-bar-item w3-button">Basics of Derivatives</a>
            <a href="quiz2.php" class="w3-bar-item w3-button">Differentiation Rules</a>
			<a href="quiz3.php" class="w3-bar-item w3-button">Products of Quotient Rules</a>
			<a href="quiz4.php" class="w3-bar-item w3-button">Derivatives of Inverse Trigonometric</a>
			<a href="quiz5.php" class="w3-bar-item w3-button">Power and Chain Rule</a>
			<a href="quiz6.php" class="w3-bar-item w3-button">Implicit Differentiation</a>
			<a href="quiz7.php" class="w3-bar-item w3-button">Logarithmic Differentiation</a>
			<a href="quiz8.php" class="w3-bar-item w3-button">Linear Approximation</a></div>
      
        <a onclick="myAccFunc7()" href="#" class="w3-bar-item w3-button">Applications<i class="fa fa-caret-down"></i></a>
            <div id="demoGcc4" class="w3-bar-block w3-hide w3-padding-large w3-medium">
            <a href="quiz9.php" class="w3-bar-item w3-button">Max and Min of Functions</a>
			<a href="quiz10.php" class="w3-bar-item w3-button">Mean Value Theorem</a>
			<a href="quiz11.php" class="w3-bar-item w3-button">Derivatives and the Shape of a Graph</a></div>

        <a onclick="myAccFunc8()" href="#" class="w3-bar-item w3-button">Integrals<i class="fa fa-caret-down"></i></a>
            <div id="demoGcc5" class="w3-bar-block w3-hide w3-padding-large w3-medium">
            <a href="quiz12.php" class="w3-bar-item w3-button">Definite Integrals</a>
			<a href="quiz13.php" class="w3-bar-item w3-button">Midpoint Rule</a>
			<a href="quiz14.php" class="w3-bar-item w3-button">Fundamental Theorem of Calculus</a>
			<a href="quiz15.php" class="w3-bar-item w3-button">Indefinite Integrals</a>
			<a href="quiz16.php" class="w3-bar-item w3-button">Substitution rule</a>
			<a href="quiz17.php" class="w3-bar-item w3-button">Integration by Parts</a></div>
      </div>
	  
    <a onclick="myAccFunc2()" href="javascript:void(0)" class="w3-bar-item w3-button" >
      Resources <i class="fa fa-caret-down"></i>
    </a>    
	
	  <!-- bars under resources -->
      <div id="demoFcc" class="w3-bar-block w3-hide w3-padding-large w3-medium">
        <a href="survivingRIT.php" class="w3-bar-item w3-button">Surviving RIT</a>
      </div>
  </div>
  <a href="comment.php" class="w3-bar-item w3-button w3-padding">Comment</a> 
  <a href="about.php" class="w3-bar-item w3-button w3-padding">About us</a> 
    <a href="login.php" class="w3-bar-item w3-button w3-padding">Login</a> 


</nav>

<!-- Top menu on small screens -->
<header class="w3-bar w3-top w3-hide-large w3-black w3-xlarge">
  <div class="w3-bar-item w3-padding-24 w3-wide">Calculus</div>
  <a href="javascript:void(0)" class="w3-bar-item w3-button w3-padding-24 w3-right" onclick="w3_open()"><i class="fa fa-bars"></i></a>
</header>

<!-- Overlay effect when opening sidebar on small screens -->
<div class="w3-overlay w3-hide-large" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>

<!-- !PAGE CONTENT! -->
<div class="w3-main" style="margin-left:250px">

  <!-- Push down content on small screens -->
  <div class="w3-hide-large" style="margin-top:83px"></div>
  
  <!-- Top header -->
  <header class="w3-container w3-xlarge">
    <p class="w3-left"><?= $title ?></p> <br/>
    </header>




  </header>



