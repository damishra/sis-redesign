<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<meta content="width=device-width" />
		<title><?= $title ?></title>
		<link rel="stylesheet" type="text/css" href="css/style.css">
	</head>