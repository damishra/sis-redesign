<?php
	$title = "Calculus - Integrals - Lesson 3";
	require_once("includes/header.inc.php");
?>
 <script>
  function changePic1()
  {
    document.getElementById('ex1').src='resources/int23.png';
  }
  function changePic2()
  {
    document.getElementById('ex1').src='resources/int21.png';
  }
  function changePic3()
  {
    document.getElementById('ex2').src='resources/int24.png';
  }
  function changePic4()
  {
    document.getElementById('ex2').src='resources/int22.png';
  }
 
  </script>
<div class="w3-container w3-text-grey" id="L1"> 
  <p>Indefinite Integrals</p></div>

  <div class="board">
   <div class="whitefont">
   <br/>
   <h2> What to know </h2>
    <div class="imgs" id= "yeet"> <img src="resources/int18.png" id="img2"/> </div>
    <br/>
    <p> The image to the right is to show that indefinite integral is basically the same as definite in the context of how we need to find the antiderivative of the function to determine the integral. </p>
<br/><br/><br/> 
    <div class="imgs" id="yeet"> <img src="resources/int19.png" id="img1"> </div>
    
    <br/><br/>
    <p> Here is a table of indefinite integrals. It is important to keep in mind the difference between indefinite and definite. A definite integral is a number where an indefinite integral is a function. Definite will have the lower limit and upper limit.
    </p>
    <br/><br/><br/><br/><br/>
    
    <p> A question below utilizing the table of indefinite integrals. **Example**</p>

    <div class="imgs" id="yeet"> <img src="resources/int20.png" id="img2"> </div>
    <br/><br/><br/> <br/><br/>


<br/><br/><br/> 





    <br/><br/><br/>
    
   
    <br/>
 	<br/>

  
    </div>

    </div>
  
    <?php
    require_once("includes/tip.inc.php");
    ?>
  
  <!-- Footer -->
    <div class="foot" id="footer">
    <br/>
<center>
        <p><div class="pratice"><img id="ex1" src="resources/int21.png" alt="Example 5"/></div><br/>
          <button id="answer" onclick="changePic1()">Answer</button>
          <button id="question" onclick="changePic2()">Back to Question</button>
        </p><br/>
        
        <p><div class="pratice"><img id="ex2" src="resources/int22.png" alt="Example 6"/><br/></div>
          <button id="answer2" onclick="changePic3()">Answer</button>
          <button id="question2" onclick="changePic4()">Back to Question</button>
        </p><br/>
        
      </center>
  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>
  </div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>