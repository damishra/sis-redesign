<?php
	$title = "Calculus - Lesson 1";
	require_once("includes/header.inc.php");
?>
  <script>
  function changePic1()
  {
    document.getElementById('ex1').src='resources/img6.png';
  }
  function changePic2()
  {
    document.getElementById('ex1').src='resources/img5.png';
  }
  function changePic3()
  {
    document.getElementById('ex2').src='resources/img8.png';
  }
  function changePic4()
  {
    document.getElementById('ex2').src='resources/img7.png';
  }
  function changePic5()
  {
    document.getElementById('ex3').src='resources/img10.png';
  }
  function changePic6()
  {
    document.getElementById('ex3').src='resources/img9.png';
  }
  </script>
  <div class="w3-container w3-text-grey" id="L1"> 
  <p>Basics of Derivatives || Other Notations </p></div>

  <div style="width:950px; height: 750px; background-color:black;">
    <div style="border: 4px solid black; float: left;"> <img src="resources/img1.png" width="300px" height="100px"> </div>
    <br/><br/><br/>
    <p style="color:white; float: left;"> (<i> Just for reference </i>) is also the same as  ----> </p>
    <div style="border: 4px solid black; float: left;"> <img src="resources/img2.png" width="300px" height="100px"> </div>
    <br/><br/><br/><br/>
    <div style="color:white;">
    <br/>
    <p> 
    <ul>
    <li> The <u>derivative of a function <i>' f '</i> at a number <i>' a '</i></u> is defined by the equation to the top left. </li>
    <li> By following that equation and the steps shown in the exercise when solving similiar Derivative questions, you are 100% most likely to get the correct answer. </li> 
    </ul> </p>
    
    <div style="border: 4px solid black; float: left;"> <img src="resources/img3.png" width="400px" height="300px"> </div>
    <p style="font: 10px;"> <u> Using the image to the left as reference. Steps to approach these questions. </u> <br/>
        1. Find out the equation that the question is asking you to determine the deriviatve of. <br/>
        2. For f(a+h), plug a+h for the x in the f(x) by subbing in all the x with a+h. And put that in the derivative equation in the place of f(a+h). <br/>    
        3. For f(a), plug a for the x in the f(x) by subbing in all the x with a. And put that in the derivative equation in the place of f(a). <br/>
        4. After plugging in f(a+h) and f(a) , simplify the limit by combining like terms. <br/>
        5. Then find the limit when h approaching 0, after the equation has been simplified. <br/>
        6. Finally substitute term a with an x. And that new equation is the derivative of the original equation.  </p>
  <br/><br/>
    <div style="border: 4px solid black; float: left;"> <img src="resources/img4.png" width="400px" height="100px"> </div>
    <p><u> The Other notations of derivatives </u> <br/>
    Of the 7 different type of notations displayed by the image to the left, <u> the first 5 ( left to right ) </u> are the notations you will see very often. <br/><br/><br/> These symbols are by no means any sort of representation of ratio, but just a simple synonym for derivative of f(x). They are differentiation operators as they just indicate the operation of differentiation, which is the process of calculating a derivative.
    </p>
  
    </div>

    </div>
  
    <p> <div>Sample Problems <br/> *Analyzing other Problems and how they are solved are great ways to understand how to find the derivative of a function*<br/> *Make sure you attempt the questions before checking the answers. Also, utilize the sample question that was given already. *</div> </p>
  
  <!-- Footer -->
    <div style="width:950px; height: 700px; background-color:#D3D3D3;" id="footer">
    <br/><br/>
    
<center>
        <p><img id="ex1" src="resources/img5.png" alt="Example 5" style="height:25%;width:35%;"/><br/>
          <button id="answer" onclick="changePic1()">Answer</button>
          <button id="question" onclick="changePic2()">Question</button>
        </p><br/><br/><br/>
        
        <p><img id="ex2" src="resources/img7.png" alt="Example 6" style="height:25%;width:35%;"/><br/>
          <button id="answer2" onclick="changePic3()">Answer</button>
          <button id="question2" onclick="changePic4()">Question</button>
        </p><br/><br/><br/>
        
        <p><img id="ex3" src="resources/img9.png" alt="Example 7" style="height:25%;width:35%;"/><br/>
          <button id="answer3" onclick="changePic5()">Answer</button>
          <button id="question3" onclick="changePic6()">Question</button>
        </p>
      </center>
      
  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>