<?php

$title="comment";
require_once("includes/header.inc.php");
require_once("start.php");

if(!empty($_POST)){

	$query = "INSERT INTO comments SET name='". $_POST["name"] . "',
				comment='". $_POST["comment"] . "'" ;

	$result = mysqli_query($mysqli,$query);
	$num_rows = mysqli_affected_rows($mysqli);
	
	// if($result && $num_rows >0){
// 		$msg = $_POST["name"] . "was successful added to the DB.";
// 		}
}
?>
  <div class="w3-container w3-text-grey" id="comment"> 
  <p>Site Comment</p></div>
<div style="border: 4px solid black;">
<br/>
 <!-- 
 <div style="width:950px; height: 750px; background-color:black;">
    <div style="color:white;">
 -->
<form method = "post">
	<span>Name:</span>
<input type="text"
       name="name"
       id="name"
       size="20"
       maxlength="10"/><br/><br/>
<span>Comment:</span>
<textarea rows="7" cols="50"
	 	  name="comment"
	 	  style="vertical-align:top;"></textarea><br/>
<input type="submit"
	   style="margin-left:20%;"/><br/>
</form>

<?php

 	$query = "SELECT *
 			  FROM
 			  comments";
 
 	$result = mysqli_query($mysqli,$query);
 	
 	$num_rows = mysqli_affected_rows($mysqli);
	echo "<p style='text-align:center;'>There are $num_rows people have commented</p>";
 	
 	
 	if($result && $num_rows >0){
 	
 	while ($row = mysqli_fetch_assoc($result)){
 	echo "<div class='col-sm-2' style='margin-left:3%;'> " . "<em>" .$row["name"] . ":</em><br/>
 	&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;" .  $row["comment"]
 			. "</div>";
 		}
 	
 	}
 	
 ?>
 <br/>
 </div>
<!-- 
</div>
  </div>
 --><!-- 


  <div class="w3-black w3-center w3-padding-24"></div>
 -->


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>