<?php
	$title = "Calculus - Application - Lesson 2";
	require_once("includes/header.inc.php");
?>
 <script>
  function changePic1()
  {
    document.getElementById('ex1').src='resources/ap5.png';
  }
  function changePic2()
  {
    document.getElementById('ex1').src='resources/ap3.png';
  }
  function changePic3()
  {
    document.getElementById('ex2').src='resources/ap6.png';
  }
  function changePic4()
  {
    document.getElementById('ex2').src='resources/ap4.png';
  }
 
  </script>
<div class="w3-container w3-text-grey" id="L1"> 
  <p>Max and Min of a Function</p></div>

  <div class="board">
   <div class="whitefont">
   <br/>
   <h2> What to know </h2>
    <p> What the Fermat's Theorem is that it helps determine whether the function [ f(x)] has a local maximum or minimum at x. How this theorem is related to the derivatives is that the derivative of the function and making it equal to 0, helps find the local max and min. </p><p> A critical number or critical point of a function is the value of  x when the derivative of f(x) is equal to 0 or when the derivative does not exist. </p>

    <div class= "imgs" id= "yeet"> <img src="resources/ap1.png" id="img1"/> </div>
    <br/>
    <p> To the Left is a good example in finding critical points. Critical Points also include max and mins. So in the example above, the first step is to find the derivative of the function using the differentiable rules. Then after determining the derivative, make the equation equal to zero as you obtain the values of x. The problem above, we have determined that 12 - 8x = 0. And when you solve for the x, we get that x is equal to 0 and 3/2. We got x equal 0 because the derivative of f(x) does not exist when x= 0. 
    </p>

    <br/><br/><br/>
    <div class= "imgs" id="yeet"> <img src="resources/ap2.png" id="img1"> </div>
   <p> The problem to the left is a good example of how common questions regarding the absolute maximum and minimum values of the function may look like. </p><p>
The first step is to find the derivative of the function, in which then after you would make that derivative equal to 0 to solve for the x. These x values will represent possible critical numbers which at the same time usually lies between the given interval ( if given). Then using the x values derived from making the derivative equal to 0 along with the given x values in the closed interval, substitute them into the actual function to find the y value if you were to plot it on the graph. By plotting it on a graph it is very to determine which points are max and min. </p>
    <br/>
 	<br/>

  
    </div>

    </div>
  
    <?php
    require_once("includes/tip.inc.php");
    ?>
  
  <!-- Footer -->
    <div class="foot" id="footer">
    <br/>
<center>
        <p><div class="pratice"><img id="ex1" src="resources/ap3.png" alt="Example 5"/></div><br/>
          <button id="answer" onclick="changePic1()">Answer</button>
          <button id="question" onclick="changePic2()">Back to Question</button>
        </p><br/>
        
        <p><div class="pratice"><img id="ex2" src="resources/ap4.png" alt="Example 6"/><br/></div>
          <button id="answer2" onclick="changePic3()">Answer</button>
          <button id="question2" onclick="changePic4()">Back to Question</button>
        </p><br/>
        
      </center>
  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>
  </div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>