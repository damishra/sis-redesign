<?php
	$title = "Calculus - Lesson 8";
	require_once("includes/header.inc.php");
?>
  <div class="w3-container w3-text-grey" id="L1"> 
  <p>Logarithmic Differentiation </p></div>

  <div style="width:950px; height: 750px; background-color:black;">
    <div style="color:white;">
    
     <div style="border: 4px solid black; float: left;"><img src="resources/l8/p1.png" alt="picture 1" width="400px" height="300px"></div>
	<p><u>Steps in logarithmic differentiation</u>
	</p>
    <p>
    First take the natural log of both sides of the equation f(x).
     And use the Laws of Logarithms to simplify. Next then different implicitly with respect to x.
      Then solve for the resulting equation for the resulting equation for the first derivative of y.
       One thing you will notice about these problems are that at the end of implicitly is that you are going to sub back the original function when you plug in y.
    </p>
  <!-- Footer -->
    <div style="width:950px; height: 700px; background-color:#D3D3D3;" id="footer">
    <br/><br/>
 

</div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>