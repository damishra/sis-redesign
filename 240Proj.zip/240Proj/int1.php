<?php
	$title = "Calculus - Integrals - Lesson 1";
	require_once("includes/header.inc.php");
?>
 <script>
  function changePic1()
  {
    document.getElementById('ex1').src='resources/int8.png';
  }
  function changePic2()
  {
    document.getElementById('ex1').src='resources/int6.png';
  }
  function changePic3()
  {
    document.getElementById('ex2').src='resources/int9.png';
  }
  function changePic4()
  {
    document.getElementById('ex2').src='resources/int7.png';
  }
 
  </script>
<div class="w3-container w3-text-grey" id="L1"> 
  <p>Fundamental Theorems of Calculus</p></div>

  <div class="board">
   <div class="whitefont">
   <br/>
   <h2> What to know </h2>
    <div class="imgs" id= "yeet"> <img src="resources/int1.png" id="img3"/> </div>
  
    <p> Basically when finding the integral of function, you are just looking for the anti-derivative of that function. So you would be just be working backwards using what you know about derivatives. However, you will realize that the techniques will help finding the integrals a lot quicker.</p>

    <div class="imgs" id="yeet"> <img src="resources/int2.png" id="img4"> </div>
    <div class="imgs" id="yeet"> <img src="resources/int3.png" id="img4"> </div>
    <div class="imgs" id="yeet"> <img src="resources/int4.png" id="img2"> </div>
    <br/><br/><br/><br/><br/>
    <p> When asked to find an integral, figure out the anti-derivative of the function. After finding the anti-derivative, plug in the values of <i>a</i> and <i>b</i> into seperate anti-derivative function and then subtract the two values. That resultant is the value of the intergral when evaluated. Look at the images above for reference.

    </p>

    <p> *** Important to keep in mind that when you integrating an integral with no <i>a</i> and <i>b</i> values, after finding the anti-derivative of the function, make sure to add a " + C " at the end of the anti-derivative.*** </p>

    <br/><br/><br/>
    
   
    <br/>
 	<br/>

  
    </div>

    </div>
  
    <?php
    require_once("includes/tip.inc.php");
    ?>
  
  <!-- Footer -->
    <div class="foot" id="footer">
    <br/>
<center>
        <p><div class="pratice"><img id="ex1" src="resources/int6.png" alt="Example 5"/></div><br/>
          <button id="answer" onclick="changePic1()">Answer</button>
          <button id="question" onclick="changePic2()">Back to Question</button>
        </p><br/>
        
        <p><div class="pratice"><img id="ex2" src="resources/int7.png" alt="Example 6"/><br/></div>
          <button id="answer2" onclick="changePic3()">Answer</button>
          <button id="question2" onclick="changePic4()">Back to Question</button>
        </p><br/>
        
      </center>
  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>
  </div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>