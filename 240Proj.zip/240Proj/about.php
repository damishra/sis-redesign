<?php
	$title = "About";
	require_once("includes/header.inc.php");
?>


  <div id="aboutBlock" style="width:950px; height: 750px; background-color:#282828;">
	</br>
    <body id="about">
   
	</br>
    <!--#include file="includes/navbar.html" -->
    <div>
                <h2>This is the Dank Meme Machine's Calculus Site. </h2>
				<h3>This site was created to do the following:</h3>
                <ul>
                    <li>Provide additional review material and help to students who are looking for extra help outside of the classroom.</li>
                    <li>Provide students with basic brick and mortar understanding of calculus topics so as to more easily understand the advanced ones.</li>
                    <li>Provide mock quizzes that contain the type of questions that are common in basic Calculus courses to estimate their scores on similiar quizzes or test in the Calculus course.</li>
                    <li>Provide students RIT specific information on taking math courses</li>
                </ul>
                <h2>Who is our Audience?</h2>
                <p>
                    Our website targets RIT math students but this site would be useful to anyone who is trying to find additional help with 
                    Calculus outside of the classroom. Our website would aid in understanding most of the simple topics of Calculus.
                </p>
				<h3>Our sources</h3>
				<ul>
					<li>The Pearson Calculus textbook</li>
					<li>https://www.pearson.com/us/higher-education/math---science/mathematics/calculus.html</li>
					<li>https://www.khanacademy.org/</li>
				</ul>
    </div>
	</body>
  </div>

  