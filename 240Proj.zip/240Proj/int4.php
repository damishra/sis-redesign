<?php
	$title = "Calculus - Integrals - Lesson 4";
	require_once("includes/header.inc.php");
?>
 <script>
  function changePic1()
  {
    document.getElementById('ex1').src='resources/i5.png';
  }
  function changePic2()
  {
    document.getElementById('ex1').src='resources/i4.png';
  }
  
  
 
  </script>
<div class="w3-container w3-text-grey" id="L1"> 
  <p>U-Substitution</p></div>

  <div class="board">
   <div class="whitefont">
   <br/>
   <h2> What to know </h2>
    <br/>
    <p> An efficient technique for solving integrals is using U-Substition, which is defined below. Essentially, you are trying to simplify the function by changing it to terms of u. The whole idea that it helps make integrating easier, saving students from working with too many coefficients. </p>
    <div class="imgs" id= "yeet"> <img src="resources/i1.png" id="img2"/> </div>


    <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>


    <div class="imgs" id="yeet"> <img src="resources/i2.png" id="img1"> </div>
    
    <div class="imgs" id="yeet"> <img src="resources/i3.png" id="img1"> </div>
    
    <br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>
    <p> Two practice examples right above. In both examples, its clear that when using U-Sub, first find the <i> u </i>. Then find the <i> du </i>. After determing <i>du</i>, put it in terms in which you cancel out some terms from the orginal function. After doing so and having the function all in terms of <i>u</i> and <i>du</i>, integrate it, in which towards the final end, substitute <i>u</i> back into <i>x</i>. 

    </p>
    <div class="imgs" id="yeet"> <img src="resources/i6.png" id="img2"> </div>

    <br/><br/><br/>
    <p> This is the U-Substitution for Definite Integrals. It is basically the same concept as the how it may be used for Indefinite Integrals. The only difference is that it is important to also change the upper and bottom limits to terms of <i>u</i>.
</p> 
    <br/><br/>
    <div class="imgs" id="yeet"> <img src="resources/i7.png" id="img1"> </div>
    <br/><br/><br/> <br/><br/>
    <br/><br/>



<br/><br/><br/> <br/><br/>
<p> Check the question above for an example.</p>
<br/>






  

  
    </div>

    </div>
  
    <?php
    require_once("includes/tip.inc.php");
    ?>
  
  <!-- Footer -->
    <div class="foot" id="footer">
    <br/>
<center>
        <p><div class="pratice" ><img id="ex1" src="resources/int4.png" alt="Example 5"/></div><br/>
          <button id="answer" onclick="changePic1()">Answer</button>
          <button id="question" onclick="changePic2()">Back to Question</button>
        </p><br/>
       
        
      </center>
  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>
  </div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>