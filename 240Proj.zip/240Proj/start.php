<?php

	$mysqli = mysqli_connect("localhost","zxj5975","jiangxiuqin","zxj5975");
	
	
	if(!$mysqli){
	echo "Connection fauked ". mysqli_connect_error();
	die();
	}
?>