<?php
	$title = "Calculus - Lesson 2";
	require_once("includes/header.inc.php");
?>

  <div class="w3-container w3-text-grey" id="L1"> 
  <p>Differentiation Rules || Part 1</p></div>
  <div style="width:950px; height: 750px; background-color:black;">
  <div style="color:white;">
    <div style="border: 4px solid black; float: left;"> <img src="resources/l2/p1.png" width="400px" height="90px"> </div>
    <div style="border: 4px solid black; float: left;"> <img src="resources/l2/p2.png" width="500px" height="90px"> </div>
	<p><u>Derivative of a Constant Function</u> <br/>
	This is derived from if the constant function f(x) = c. The graph of the function is the horizontal line y=c,
	which would make the slope equal to 0. Making the derivative of f(x) equal to 0.</p>
	<br/><br/>
	<div style="border: 4px solid black; float: left;"> <img src="resources/l2/p3.png" width="450px" height="100px"> </div>
	<p><u>The Power Rule</u><br/>
	The power rule is true because of the following proofs below
	</p><br/><br/><br/>
	<div style="border: 4px solid black; float: left;"> <img src="resources/l2/p4.png" width="400px" height="300px"> </div>
	<p><u>Tip</u><br/>
	Knowing the proofs for the power rule is not at all important to have memorized. However it is important to remember the
	 whole concept of the Power Rule, is that you can easily find the derivative of functions with variables to the "n" power.
	 For example, if you were to take a look at the example question in the " Basics of Derivatives" Page, The derivative of
	that function is 2x - 8. <u>f(x)=x^2-8x+9</u> 
	We got its derivative by using the concept of Power Rule and the definition of the derivative of a constant.
	The first term is " x to the power of 2 ". Since the power is 2, we are going to subtract that by 1 and get the new power to be 1.
	The "2" then is multiplied by the coefficient of the variable which then becomes " 2x ". The next term
	is " - 8x ". The power is 1, so 1 minus 1 is 0, making the new power 0 for that term. The "1" then is multiplied to
	the coefficient which is -8, which just remains the same. However since the x is to the power of 0 is 1, the value of
	-8 still remains the same. The final term which is a constant, just becomes 0, because the derivative of a constant is 0.
	At the end the derivative of f(x)is"2x-8".
	
  </div>
</div>
  <div class="w3-black w3-center w3-padding-24"></div>

  <!-- End page content -->





<script src="includes/sidebarscript.js"></script>

</body>
</html>