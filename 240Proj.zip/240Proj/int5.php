<?php
  $title = "Calculus - Integrals - Lesson 3";
  require_once("includes/header.inc.php");
?>
 <script>
  function changePic1()
  {
    document.getElementById('ex1').src='resources/i13.png';
  }
  function changePic2()
  {
    document.getElementById('ex1').src='resources/i12.png';
  }
  function changePic3()
  {
    document.getElementById('ex2').src='resources/i14.png';
  }
  function changePic4()
  {
    document.getElementById('ex2').src='resources/i11.png';
  }
 
  </script>
<div class="w3-container w3-text-grey" id="L1"> 
  <p>Integration by Parts</p></div>

  <div class="board">
   <div class="whitefont">
   <br/>
   <h2> What to know </h2>
    <p> Integration by Parts has got to be the easiest thing to go over when learning about Integration. It is such a useful technique as well. The secret to it is to not mess up when selecting the <i>u,du,v,and dv.</i> In addition, as long as you follow the formula, shown below, you can't really go wrong. </p>  

    <div class="imgs" id= "yeet"> <img src="resources/i8.png" id="img3"/> </div>
    <br/>  <br/><br/>
   
    <br/><br/><br/>
    
    <p> In the examples below, both solutions has the variables defined and they are plugged into the formula. Then, simplify the formula. As mentioned before it is important to get the correct derivatives and anti-derivatives of the integral. </p>
    <div class="imgs" id="yeet"> <img src="resources/i9.png" id="img1"> </div>
    
  

    <div class="imgs" id="yeet"> <img src="resources/i10.png" id="img1"> </div>
    <br/><br/><br/> <br/><br/>


<br/><br/><br/> 





    <br/><br/><br/>
    
   
    <br/>
  <br/>

  
    </div>

    </div>
  
    <?php
    require_once("includes/tip.inc.php");
    ?>
  
  <!-- Footer -->
    <div class="foot" id="footer">
    <br/>
<center>
        <p><div class="pratice"><img id="ex1" src="resources/i12.png" alt="Example 5"/></div><br/>
          <button id="answer" onclick="changePic1()">Answer</button>
          <button id="question" onclick="changePic2()">Back to Question</button>
        </p><br/>
        
        <p><div class="pratice"><img id="ex2" src="resources/i11.png" alt="Example 6"/><br/></div>
          <button id="answer2" onclick="changePic3()">Answer</button>
          <button id="question2" onclick="changePic4()">Back to Question</button>
        </p><br/>
        
      </center>
  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>
  </div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>