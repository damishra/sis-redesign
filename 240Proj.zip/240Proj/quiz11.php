<?php
	$title = "Calculus - Quiz 11";
	require_once("includes/header.inc.php");
?>


	<script>
		function $( ele ) {
			return document.getElementById( ele );
		}
		var answers1 = ["A"];//put all the answers in vars
		var answers2 = ["D"];
		var numCorrect = 0;
		function submitForm(){
			console.log("entered validate");
			var wrongMsg = ""; //message that will say which is wrong
			var answer1 = document.forms[0].question1.value;
			var answer2 = document.forms[0].question2.value;
			for(i = 0; i < answers1.length; i++){
				if(answer1 == answers1[i]){
					numCorrect += 1;
				}
				else{
					wrongMsg += "Question 1 wrong, correct answer is: " + answers1[0] + " <br/>";
					$( "ques1" ).style.border = "5px solid red";
					$( "q1answer1" ).src = "resources/quiz11/q11q1answer.PNG"
				}
				if(answer2 == answers2[i]){
					numCorrect += 1;
				}
				else{
					wrongMsg += "Question 2 wrong, correct answer is: " + answers2[0] + " <br/>";
					$( "ques2" ).style.border = "5px solid red";
					$( "q1answer2" ).src = "resources/quiz11/q11q2answer.PNG"
				}
				window.scrollTo(0, 0);
				if( wrongMsg ){
					var resultsDiv = $( "results" );
							
					$( "results" ).innerHTML =
					"The following were incorrect. Look below for the correct solutions.<br/>" + wrongMsg;
					$( "results" ).style.display = "block";
					return false; // prevent form from submitting
				}
				return true;
			}
		}
	</script>
	<body id="quizzes"><!--Use for first part of active css-->
	<header>
		<h1>Quiz 11 - Derivatives and the Shape of a Graph</h1>
	</header>
	<!--#include file="includes/navbar.html" --> <!-- Includes the nav bar, starts with <nav> ends with </nav>-->
	
	<!--Quiz content below-->
	<form action="quiz12.php" method="post" name="form" 
		onsubmit="return submitForm();">
		
		<div id="quizContent">
			<div id="results"></div>
			<h3>Question 1</h3>
			<p>
				<img id="ques1" class="thumbnail" src="resources/quiz11/q11q1.PNG" alt="question1">
				<img id="q1answer1" src="" alt=""><br/>
				Your Answer:
				<input type="text"
					name="question1"
					id="question1"
					maxlength="14"
					required="required"/>
				
			</p><br/><br/>
			<h3>Question 2</h3>
			<p>
				<img id="ques2" src="resources/quiz11/q11q2.PNG" alt="question2">
				<img id="q1answer2" src="" alt=""><br/>
				Your Answer:
				<input type="text"
					name="question2"
					id="question2"
					maxlength="14"
					required="required"/>
			</p><br/><br/>
			<button id="submit">Submit Quiz</button>
		</div>
	</form>
	<script src="includes/sidebarscript.js"></script>
</body>

</html>