<?php
	$title = "Calculus - Lesson 4";
	require_once("includes/header.inc.php");
?>
  <div class="w3-container w3-text-grey" id="L1"> 
  <p>The Product and Quotient Rules</p></div>

  <div style="width:950px; height: 750px; background-color:black;">
    <div style="color:white;">
    
    <div style="border: 4px solid black; float: left;"><img src="resources/l4/p1.png" alt="picture 1" width="500px" height="90px"></div>
    <p><u>The Product Rule</u>
	It says the derivative of a product of two functions is the first function times the derivative of
	 the second function plus the second function times the derivative of the first function..</p>
	 <br/><br/><br/><br/><br/><br/><br/>
    <div style="border: 4px solid black; float: left;"><img src="resources/l3/p2.png" alt="picture 2" width="500px" height="90px"></div>
    <p><u>The Quotient Rule</u>
    What you are going to do here, is multiple the denominator to the derivative of the numerator minus the numerator times the derivative of the denominator,
     which is then all divided by the square of the denominator. This is presented in the image above.</p>
    

  </div>
  </div>

  <div class="w3-black w3-center w3-padding-24"></div>


  <!-- End page content -->



<script src="includes/sidebarscript.js"></script>
</body>
</html>