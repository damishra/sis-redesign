drop database if exists sis;
create database sis;
use sis; 

CREATE TABLE role (
	role INT(11) NOT NULL,
	title VARCHAR(64) NOT NULL UNIQUE,
	PRIMARY KEY(role)
);

CREATE TABLE user (
	UID INT(11) NOT NULL,
	first_name VARCHAR(32) NOT NULL,
    middle_name VARCHAR(32),
	last_name VARCHAR(32) NOT NULL,
    preferred_name varchar(32),
    email varchar(50),
    phone varchar(15),
    address text,
	PRIMARY KEY(UID)
);

create table login (
  username varchar(64) NOT NULL,
  UID int(11) NOT NULL,
  hash nvarchar(128) NOT NULL,
  salt nvarchar(128) not null,
  role INT(11) NOT NULL,
  primary key (username),
  foreign key(role) references role(role) on delete cascade on update cascade,
  foreign key (UID) references user(UID)
);

CREATE TABLE department (
	dep_id VARCHAR(11) NOT NULL,
	title VARCHAR(64) NOT NULL UNIQUE,
	PRIMARY KEY (dep_id)
);

CREATE TABLE course (
	course_id int(11) NOT NULL,
	dep_id VARCHAR(11) NOT NULL,
	title VARCHAR(60) NOT NULL,
	description TEXT NOT NULL,
	PRIMARY KEY (course_id, dep_id),
	foreign key (dep_id) references department(dep_id) on delete cascade on update cascade
);

create table grades (
  grade varchar(3),
  weightage DECIMAL(3,2),
  primary key (grade)
);

create table course_list (
  UID int(11) not null,
  course_id int(11) not null,
	dep_id varchar(11) not null,
  grade varchar(3),
  foreign key (UID) references user(UID) on update cascade on delete cascade,
	foreign key (dep_id) references course(dep_id) on update cascade on delete cascade,
  foreign key (course_id) references course(course_id) on update cascade on delete cascade,
  foreign key (grade) references grades(grade) on update cascade,
  primary key(UID)
);

CREATE TABLE major (
	major_id VARCHAR(11) NOT NULL,
	code CHAR(4) NOT NULL UNIQUE,
	title VARCHAR(64) NOT NULL UNIQUE,
	department varchar(11) NOT NULL,
	PRIMARY KEY (major_id),
	FOREIGN KEY (department) REFERENCES department(dep_id) ON UPDATE CASCADE
);

CREATE TABLE major_course (
	major_id VARCHAR(11) NOT NULL,
	course_id INT(11) NOT NULL,
	required TINYINT(1) NOT NULL DEFAULT '0',
	FOREIGN KEY (major_id) REFERENCES major(major_id) ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY (course_id) REFERENCES course(course_id) ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE semester (
	semester_id INT(11) NOT NULL AUTO_INCREMENT,
	start_date DATE NOT NULL,
	end_date DATE NOT NULL,
	code CHAR(5) NOT NULL UNIQUE,
	PRIMARY KEY (semester_id)
);

CREATE TABLE course_section (
	section_id INT(11) NOT NULL AUTO_INCREMENT,
	course_id INT(11) NOT NULL,
	semester_id INT(11) NOT NULL,
	PRIMARY KEY (section_id),
	FOREIGN KEY (course_id) REFERENCES course(course_id) ON UPDATE CASCADE,
	FOREIGN KEY (semester_id) REFERENCES semester(semester_id) ON UPDATE CASCADE
);

CREATE TABLE course_section_enroll_type (
	enrollment_id INT(11) NOT NULL,
	title VARCHAR(64) NOT NULL UNIQUE,
	PRIMARY KEY(enrollment_id)
);

CREATE TABLE course_section_user (
	section_id INT(20) NOT NULL UNIQUE,
	UID INT(11) NOT NULL UNIQUE,
	enrollment_id INT(11) NOT NULL,
	FOREIGN KEY (section_id) REFERENCES course_section(section_id) ON UPDATE CASCADE,
	FOREIGN KEY (UID) REFERENCES user(UID) ON UPDATE CASCADE,
	FOREIGN KEY (enrollment_id) REFERENCES course_section_enroll_type(enrollment_id) ON UPDATE CASCADE,
  primary key (section_id)
);

CREATE TABLE user_advisor (
	advisor_id INT(11) NOT NULL,
	advisee_id INT(11) NOT NULL UNIQUE,
	PRIMARY KEY(advisor_id),
	FOREIGN KEY (advisor_id) REFERENCES user(UID) ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY (advisee_id) REFERENCES user(UID) ON UPDATE CASCADE ON DELETE CASCADE
);
