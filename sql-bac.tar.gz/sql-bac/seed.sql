INSERT INTO role VALUES (1, 'Faculty');
INSERT INTO role VALUES (2, 'Student');
INSERT INTO role VALUES (3, 'Admin');

insert into department values ('ISTE', 'Information Sciences and Technology');
insert into department values ('CS', 'Computer Science');
insert into department values ('SWEN', 'Software Engineering');
insert into department values ('IGME', 'Interactive Media and Game Design');
insert into department values ('CET', 'Computer Engineering Technology');
insert into department values ('CE', 'Computer Engineering');
insert into department values ('CSEC', 'Computing Security');
insert into department values ('NSSA', 'Networks and Systems Administration');
insert into department values ('EE', 'Electrical Engineering');
insert into department values ('MATH', 'Mathematics');
insert into department values ('PHYS', 'Physics');
insert into department values ('CHEM', 'Chemistry');
insert into department values ('BIO', 'Biology');

