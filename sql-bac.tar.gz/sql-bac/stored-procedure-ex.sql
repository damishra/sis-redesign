delimiter //
DROP PROCEDURE IF EXISTS countTravel //
CREATE PROCEDURE countTravel (
	IN tMode VARCHAR(20)
)
BEGIN 
	SELECT count(DISTINCT passengerID) as 'People' from passenger
	JOIN trip_people using(passengerID)
	JOIN trip USING(tripNum)
	JOIN trip_directory USING(tripNum)
	JOIN tripcodes USING(tripType)
	WHERE TypeName = tMode;
END
//
delimiter ;
